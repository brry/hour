clim <- read.table(file="clim.txt", header=TRUE)
meta <- read.table(file="meta.txt", header=TRUE,
                   sep=";", stringsAsFactors=FALSE)
clim$MESS_DATUM <- as.Date(clim$MESS_DATUM, format="%Y-%m-%d")
# plot(clim$TMK, clim$VPM, xlab="Lufttemperatur", ylab="Dampfdruck", 
#      main="Korrelation Tagesmittelwerte\nPotsdam 2018-2019, DWD",
#      las=1, pch=3, cex=1.8, col="red", cex.main=0.9)
# text(0,20, "Hi", col="blue")
# plot(clim$MESS_DATUM, clim$TXK, type="l",
#      main="Saisonalitaet sichtbar", las=1, lwd=3, col="purple",
#      xaxt="n")
# berryFunctions::monthAxis()
# 
graphics.off()
rownames(meta) <- meta$Par

pdf("climgraphs.pdf", width=10)
par(mar=c(2.5,3,2,0.2), bg="yellow")
for(var in meta$Par)
{
plot(clim$MESS_DATUM, clim[,var], type="l", xaxt="n",
     main=meta[var, "Label"], ylab="", xlab="",
     las=1)
berryFunctions::monthAxis()
}
dev.off()
berryFunctions::openFile("climgraphs.pdf")
