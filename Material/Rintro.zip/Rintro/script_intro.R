# Get started with R in a few hours
# Berry Boessenkool, berry-b@gmx.de, June 2018 - Sept 2024
# https://github.com/brry/hour (in Rstudio, SHIFT + click opens a URL)

# Comments start with a hashtag - everything behind it is ignored by R.

# send a line of code to the R console with CTRL + ENTER
# while the cursor is anywhere on the line


72-30 # simple computations can have great results ;-)

"I'm a character string"

# Make sure you're working in an R project (topright of Rstudio).
# It handles the working directory (where R reads and writes data)
# and keeps projects separated.

# Work with relative pathnames like "measurements/person1.txt"
# instead of having to include "C:/user/but_not_of_drugs/subfolder007/"
# which other people running your script would hate you for.
# (Other people includes you, 2 months later or on your second computer)



