# 1 hour intro to programming with R
# Berry Boessenkool, berry-b@gmx.de, June 2018
# https://github.com/brry/hour

# Comments start with a hashtag - everything behind it is ignored by R.
# send a line of code to the R console with CTRL + ENTER

72-30 # simple computations can have great results ;-)

"I'm a character string"
