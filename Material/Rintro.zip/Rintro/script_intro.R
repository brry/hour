# 1 hour intro to programming with R
# Berry Boessenkool, berry-b@gmx.de, June 2018 + Oct 2019
# https://github.com/brry/hour

# Comments start with a hashtag - everything behind it is ignored by R.

# send a line of code to the R console with CTRL + ENTER
# while the cursor is anywhere on the line


72-30 # simple computations can have great results ;-)

"I'm a character string"


# Now before we do anything with data, we want to tell R where to look for it.
# That way, we can work with relative paths like "measurements/person1.txt"
# instead of having to include "C:/user/but_not_of_drugs/subfolder007/"
# which other people running your script would hate you for.
# (Other people includes you, 2 months later or on your second computer)

setwd("C:/path/to/project") # Use forwardslashes (only MS Windows is weird here)
